#!/usr/bin/python

import simple_test

simple_test.test("test11", [], expect_fail=True)
