#!/usr/bin/python

import simple_test

simple_test.test("test3", ["--stringTest=aaa", "homer", "marge", "bart", "--", "one", "two", ])
