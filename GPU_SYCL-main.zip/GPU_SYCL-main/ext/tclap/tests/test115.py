#!/usr/bin/python

import simple_test

simple_test.test("test47", ['-p', '1 2.3'])
