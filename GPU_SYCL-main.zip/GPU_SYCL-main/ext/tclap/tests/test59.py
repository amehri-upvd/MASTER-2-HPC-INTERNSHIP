#!/usr/bin/python

import simple_test

simple_test.test("test9", ["-VVV", "-N", "--noise", "-r", "blah", ])
