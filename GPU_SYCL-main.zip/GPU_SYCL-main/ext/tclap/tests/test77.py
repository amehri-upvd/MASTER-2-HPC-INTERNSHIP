#!/usr/bin/python

import simple_test

simple_test.test("test20", ["-ab", ], expect_fail=True)
