#!/usr/bin/python

import simple_test

simple_test.test("test14", ["-v", "3.2 -47.11 0", ])
