#!/usr/bin/python

import simple_test

simple_test.test("test3", ["--stringTest=bill", "-i=9", "-i=8", "-B", "homer", "marge", "bart", ])
