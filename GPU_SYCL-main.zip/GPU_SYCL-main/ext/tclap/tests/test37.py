#!/usr/bin/python

import simple_test

simple_test.test("test7", ["-n", "homer", "2", "-n", "marge", "1", "3", ])
