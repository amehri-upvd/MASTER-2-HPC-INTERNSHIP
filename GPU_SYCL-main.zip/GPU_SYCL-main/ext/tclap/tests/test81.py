#!/usr/bin/python

import simple_test

simple_test.test("test22", ["asdf", "asdf", "-r", "fds", "xxx", ], expect_fail=True)
