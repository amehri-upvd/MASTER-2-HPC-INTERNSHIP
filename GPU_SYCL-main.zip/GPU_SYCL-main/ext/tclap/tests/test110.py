#!/usr/bin/python

import simple_test

simple_test.test("test42", ["-h", ], head=6)
